<?php
	include "connect.php";
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
	<?php include "styles.php"; ?>
  <script src="jquery-creditcardvalidator/jquery.creditCardValidator.js"></script>
  <script src="jquery-3.2.1.min.js" type="text/javascript"></script>
  <script>
    function ValidateCard() {
      var valid = true;
      $(".demoInputBox").css('background-color', '');
      var message = "";
      
      var PhoneNumberValidation = /[0-9]{10}/;
      var EmailValidation = /[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
      var PasswordValidation = /.{6,}/;
      var CardNumberValidation = /^[0-9]{16,16}$/;
      var CVVValidation = /^[0-9]{3,3}$/;
      var ExpMonthValidation = /[0-9]{1,2}/;
      var ExpYearValidation = /[0-9]{4}/;
      
      var PhoneNumber = $("#phone").val();
      var Email = $("#email").val();
      var Password = $("#password").val();
      var cardNumber = $("#cardnum_field").val();
      var cvv = $("#cvv_field").val();
      var expmonth = $("#expmonth_field").val();
      var expyear = $("#expyear_field").val();

      if (cardNumber == "" || cvv == "") {
        message += "<div>All Fields are Required.</div>";
      }
      
      if (PhoneNumber != "" && !PhoneNumberValidation.test(PhoneNumber))
       {
         message += "<div>Phone Number is Invalid</div>";
         valid = false;        
      }
      if (Email != "" && !EmailValidation.test(Email))
       {
         message += "<div>Email is Invalid</div>";
         valid = false;        
      }
      if (Password != "" && !PasswordValidation.test(Password))
       {
         message += "<div>Password is Invalid</div>";
         valid = false;        
      }
      if (cardNumber != "" && !CardNumberValidation.test(cardNumber))
       {
         message += "<div>Card Number is Invalid</div>";
         valid = false;        
      }
      if (cvv != "" && !CVVValidation.test(cvv))
      {
        message += "<div>CVV is Invalid</div>";
        valid = false;
      }
      if (expmonth != "" && !ExpMonthValidation.test(expmonth))
      {
        message += "<div>Expiry Month is Invalid</div>";
        valid = false;
      }
      if (expyear != "" && !ExpYearValidation.test(expyear))
      {
        message += "<div>Expiry Year is Invalid</div>";
        valid = false;
      }
      
      if (message != "") {
        $("#error-message").show();
        $("#error-message").html(message);
      }
      return valid;
    }
  </script>
  <style>
    #error-message{
      display: none;  
      width: 93%;
      padding: 5px 0 0 5px;
      border: 2px solid #ff8080;
      border-radius:2px;
      background-color: #ffe6e6;
      color: #ff0000;
      text-align: left;
      margin-top: 10px;
    }
    .existing-user{      
      width: 93%;
      padding: 5px 0 0 5px;
      border: 2px solid #ff8080;
      border-radius:2px;
      background-color: #ffe6e6;
      color: #ff0000;
      text-align: left;
      margin-top: 10px;
    }
  </style>
</head>
<body style="background: linear-gradient(to bottom right, #aaaeb5, C3A6A0); min-height:100%;" >	
	<div class="lgo_container_signup">
		<img src="images/lgo.png"></img>
	</div>
	<div class="container signup_container" style="width:60%;min-width:350px;">
		<div class="signup-title-container">
			<h1 id="signup_title">Sign Up</h1>
		</div>
		<form action="signup_backend.php" method="post" class="signup_form" onsubmit = "return ValidateCard()">
			<div class="container_form">
				<div class="signup left">
					<p class="sub_title_signup">Personal Details</p>
					<div class="userdetails_field">
						<i class="fas fa-user" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Full Name" name="fullname" size="20" required>
					</div>
					<div class="userdetails_field">
						<i class="far fa-calendar" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="text" onfocus="(this.type='date')" placeholder="Date Of Birth" name="date_of_birth" size="20" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-home" style="font-size: 30px; margin-right: 4px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Address" name="address" size="49" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-home" style="font-size: 30px; margin-right: 4px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Suburb" name="suburb" size="49" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-home" style="font-size: 30px; margin-right: 4px; color: #404040"></i>
						<select name="cars" style="width: 65%; border-radius: 5px; padding: 5px;" required>
							<option value="" disabled selected>Select your state</option>
							<option value="volvo">VIC</option>
							<option value="saab">NSW</option>
							<option value="fiat">QLD</option>
							<option value="audi">WA</option>
							<option value="audi">SA</option>
							<option value="audi">TAS</option>
						 </select>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-home" style="font-size: 30px; margin-right: 4px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Postcode" name="postcode" size="49" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-home" style="font-size: 30px; margin-right: 4px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Country" name="country" size="49" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-phone" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Phone Number" id="phone" name="phone" size="50" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-envelope" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Email" id="email" name="email" size="50" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-unlock" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="password" placeholder="Password" id="password" name="password" size="50" required>
					</div>
				</div>
				<div class="signup right">
				<p class="sub_title_signup">PayMent Details</p>
					<div class="userdetails_field">
						<i class="fas fa-credit-card" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Card Number" id="cardnum_field" name="cardnum" size="20" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-clock" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px; border-radius: 5px;" type="text" placeholder="Expiry Month" id="expmonth_field" name="expmonth" size="20" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-clock" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="Expiry Year" id="expyear_field" name="expyear" size="50" required>
					</div>
					<div class="userdetails_field">
						<i class="fas fa-credit-card" style="font-size: 30px; margin-right: 5px; color: #404040"></i>
						<input style ="padding: 5px" type="text" placeholder="CVV" id="cvv_field" name="cvv" size="50" required>
					</div>
					<div class="container signup-instruction">
						<strong><p>Email should contain symbols '@' and '.'</p>
						<p>Password shoud be at least 8 characters</p>
						<p>Phone number should have 10 numbers</p>
            <p>Card Numebr should contain 16 numbers</p>
            <p>CVV should contains 3 numbers</p></strong>
					</div>
          <div id="error-message" class="container">
            <!--Card validation errors display here-->            
          </div>
          <?php 
            if (isset($_SESSION["AlreadyExistedMessage"]))
              {
          ?>
          <div class="container existing-user">
            <?php 
                  echo '<p>'.$_SESSION["AlreadyExistedMessage"].'<p>';
                  unset($_SESSION["AlreadyExistedMessage"]);
            ?>
          </div>
          <?php 
              }
          ?>
				</div>
			</div>
			<button id="signin_button" type="submit" value="Sign In">Sign Up</button>
		</form>
		<form action ="lgout.php" method="post">
			<button type="submit" id="signup_cancel_btn">Cancel</button>
		</form>
	</div>
</body>
</html>