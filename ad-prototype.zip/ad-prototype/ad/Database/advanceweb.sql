-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 17, 2019 at 03:27 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advanceweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ad_email` varchar(100) NOT NULL,
  `ad_password` varchar(100) NOT NULL,
  `ad_name` varchar(100) NOT NULL,
  `ad_dob` date NOT NULL,
  `ad_street` varchar(100) NOT NULL,
  `ad_suburb` varchar(50) NOT NULL,
  `ad_state` varchar(20) NOT NULL,
  `ad_country` varchar(30) NOT NULL,
  `ad_postcode` int(10) NOT NULL,
  `ad_phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ad_email`, `ad_password`, `ad_name`, `ad_dob`, `ad_street`, `ad_suburb`, `ad_state`, `ad_country`, `ad_postcode`, `ad_phone`) VALUES
('s&k@snk.com', '68c6c49ff31bc508f250371fad1a61e9693d691c', 'Karan Susil', '2019-05-01', '120 Spencer St', 'Melbourne', 'VIC', 'Australia', 3000, 469890386);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `b_name` varchar(100) NOT NULL,
  `b_address` varchar(100) NOT NULL,
  `b_phone` int(20) NOT NULL,
  `b_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`b_name`, `b_address`, `b_phone`, `b_email`) VALUES
('Apple', 'Docklands', 123142123, 'support@apple.com'),
('Dell', 'Docklands', 123456, 'support@dell.com'),
('Samsung', 'Docklands', 124123123, 'support@samsung.com');

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `c_email` varchar(100) NOT NULL,
  `card_num` int(16) NOT NULL,
  `exp_month` int(11) NOT NULL,
  `exp_year` int(11) NOT NULL,
  `card_cvv` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_email` varchar(100) NOT NULL,
  `c_password` varchar(100) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `c_dob` date NOT NULL,
  `c_street` varchar(100) NOT NULL,
  `c_suburb` varchar(50) NOT NULL,
  `c_state` varchar(20) NOT NULL,
  `c_country` varchar(30) NOT NULL,
  `c_postcode` int(4) NOT NULL,
  `c_phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_email`, `c_password`, `c_name`, `c_dob`, `c_street`, `c_suburb`, `c_state`, `c_country`, `c_postcode`, `c_phone`) VALUES
('s&k@snk.com', '892cced39e2359a6319dd42f9102de9b98c14024', 'susil', '1998-01-01', '31 Mutton Road', 'Fawkner', 'Vic', 'australia', 3060, 420799561);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(5) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_color` varchar(20) NOT NULL,
  `p_price` int(10) NOT NULL,
  `p_stock` varchar(20) NOT NULL,
  `b_name` varchar(100) NOT NULL,
  `p_image` varchar(1000) NOT NULL,
  `p_date_add` date NOT NULL,
  `p_category` varchar(20) DEFAULT NULL,
  `p_clicks` int(11) NOT NULL,
  `p_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_name`, `p_color`, `p_price`, `p_stock`, `b_name`, `p_image`, `p_date_add`, `p_category`, `p_clicks`, `p_status`) VALUES
(1, 'Macbook Pro 13\'', 'Blue', 2000, '10', 'Apple', 'macbook13.jpg', '2019-05-10', 'Laptops', 12, 1),
(2, 'Dell 3350', 'White', 2200, '10', 'Dell', 'dell3350.jpg', '2019-05-10', 'Laptops', 23, 0),
(3, 'Samsung x360', 'White', 1890, '10', 'Samsung', 'x360.jpg', '2019-05-10', 'Laptops', 2435, 0),
(4, 'I Mac 17\'', 'Blue', 4000, '10', 'Apple', 'imac17.jpg', '2019-05-10', 'Laptops', 12, 0),
(5, 'Iphone Xs', 'Gold', 1600, '10', 'Apple', 'xs.jpg', '2019-05-10', 'Mobile', 234, 0),
(6, 'Iphone XR', 'Black', 1250, '10', 'Apple', '1.jpg', '2019-05-10', 'Mobile', 567, 0),
(7, 'Iphone 8\r\n', 'Space Grey', 850, '10', 'Apple', 'i8.jpg', '2019-05-10', 'Mobile', 5645, 0),
(8, 'Apple Iwatch series 4', 'white', 650, '50', 'Apple', 'iwtch4.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(9, 'Samsung Gear', 'black', 350, '300', 'Samsung', 'smgw.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(10, 'Apple Iwatch Series 3', 'white', 450, '50', 'Apple', 'ser3.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(11, 'Apple Iwatch Series 2', 'white', 350, '50', 'Apple', 's2.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(12, 'Dell Inspiron 17\'', 'Black', 3900, '15', 'Dell', 'dellinspiron17.jpg', '2019-06-10', 'Laptops', 0, 0),
(13, 'Dell Inspiron 13 7000 2-in-1', 'silver', 1950, '8', 'Dell', 'dell13.jpg', '2019-05-16', 'Laptops', 0, 0),
(14, 'Galaxy samsung s10', 'black', 1800, '6', 'Samsung', 's10t.jpg', '2019-05-16', 'Mobile', 0, 0),
(15, 'Galaxy Note 10', 'Blue', 2250, '5', 'Samsung', '10note.jpg', '2019-05-16', 'Mobile', 0, 0),
(16, 'SAMSUNG GALAXY A7 ', 'Blue', 500, '12', 'Samsung', 'a7.jpg', '2019-05-16', 'Mobile', 0, 0),
(17, 'Fitbit Ionic Smart Fitness Watch', 'Slate Blue/Burnt Ora', 248, '5', 'Samsung', 'ftbt.jpg', '2019-05-16', 'Smart Watches', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ad_email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`b_name`);

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD KEY `c_email` (`c_email`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `b_name` (`b_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
