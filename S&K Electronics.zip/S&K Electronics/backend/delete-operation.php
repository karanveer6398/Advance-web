<?php
    include "connect.php";
    $sql = "select * from products";
    $result = mysqli_query($conn,$sql);
?>
<!doctype html>
<html>
    <head>
        <title>Delete</title>
          <?php include '../styles.php'; ?>
      <script>
        $(document).ready(function() {
          $('.table').on('click', 'span', function() {
              var id = $(this).attr('id');
              $.ajax(
                    {
                    type:'get',
                    url:'hideproduct.php',
                    data:'table=products&action=Update&submit=submit&p_status=0&p_id='+id,
                    success:function(data)
                    {
                      console.log("success", data);
                    }
                       
                    });
          });
      });
      </script>
      
    </head>
    <body style="margin:0;">
            <h1 style="background-color:#337ab7; margin:0 0 20px 0; color:white; padding:5px;">Remove item</h1>
        <div class="container">
          <h1>
            Please select a product:
          </h1>
          <form method="post" action="query.php">
            
            <select class="form-control" name="p_id">
            <option selected>Select product</option>
            <?php
                  if(!empty($result)){
                    while($row = mysqli_fetch_assoc($result)){
                      ?>
                      <option value = "<?php echo $row['p_id']?>"><?php echo $row['p_name']?></option>
            <?php
                    }
                  }
                ?>
          </select>
            <input type="hidden" name="table" value="products">
            <input type="hidden" name="action" value="Delete">
            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
            </form>
          </div>
        </div>
    </body>
</html>