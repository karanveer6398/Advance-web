<?php
  include 'connect.php';
  if(!empty($_GET['order_id'])){
   $id = $_GET['order_id'];
   $sql = "select orders.*, products.p_name,products.p_image ,customer.c_name,customer.c_street,customer.c_suburb,customer.c_state,customer.c_country,customer.c_postcode,customer.c_phone, customer.c_name from orders inner join customer on customer.c_email = orders.c_email inner join products on products.p_id = orders.p_id where orders.o_id = '$id' or orders.c_email = '$id'";
    $result = mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0){
      while($row = mysqli_fetch_assoc($result)){
        $orderID = $row["o_id"];
        $email = $row["c_email"];
        $pID = $row["p_id"];
        $pName = $row["p_name"];
        $pImage = $row["p_image"];
        $orderDate = $row["o_date"];
        $status = $row["o_status"];
        $cAddress = $row["c_street"]." ".$row["c_suburb"]." ".$row["c_state"]." ".$row["c_country"]." ".$row["c_postcode"];
        $cPhone = $row["c_phone"];
        $price = $row["o_price"];
        $cName = $row["c_name"];
      }
    } 
  }
?>

<html>
  <head>
    <?php include '../styles.php';?>
    <style>
      .img-responsive{
        max-width:70%;
      }
    </style>
  </head>
  <body>
    <h1 style="width:100%;margin:0;padding:5px;background-color:#337ab7;color:white;">Order Details</h1>
    <div class="container">
      <div class="row" style="display:flex;">
        
        <div style="width:600px;height:auto;">
          <img style="width:100%;" src="../images/<?php echo $pImage;?>" class="img-responsive">  
        </div>  
        <div class="row" style="flex-direction:column;margin-top:auto;margin-bottom:auto;">
          <h3>Order ID: <?php echo $orderID?></h3>
          <h3>Product ID: <?php echo $pID?></h3>
          <h3>Product Name: <?php echo $pName?></h3>
          <h3>Cutomer E-mail: <?php echo $email?></h3>
          <h3>Cutomer Name: <?php echo $cName?></h3>
          <h3>Delivery Address: <?php echo $cAddress?></h3>
          <h3>Phone: <?php echo $cPhone?></h3>
          <h3>Ordered date: <?php echo $orderDate?></h3>
          <h3>Order Status: <?php echo $status?></h3>
          <h3>PayMent Recieved: <?php echo $price?></h3>
        </div>
      </div>
      <h2>
        Update Status
      </h2>
      <form action="query.php" method="post">
        <select name="o_status" class="form-control" style="margin-bottom:20px;">
          <option>Pending</option>
          <option>Order Recieved</option>
          <option>In Progress</option>
          <option>Delivered</option>
        </select>
        <input type="hidden" name="table" value="orders">
        <input type="hidden" name="action" value="Update">
        
        <input type="hidden" name="o_id" value="<?php echo $orderID; ?>">
        <input type="submit" name="submit" value="Change Status" class="btn btn-primary">
      </form>
    </div>
    
  </body>
</html>