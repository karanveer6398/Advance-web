<?php
  for($_GET as $key => $value){
    echo $key." => ".$value;
  }
?>