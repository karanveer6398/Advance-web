<footer class="container-fluid text-center" style="display: flex;">
    <div class="left-footer" style="width: 50%; display: flex;">
      <div class="modulo" style="width: 33%">
        <p stlye="font-size: 17px">S & K Electronics</p>
        <p>About Us</p>
        <p>Career</p>
        <p>Term &amp; Conditions</p>
        <p>Privacy Policy</p>
      </div>
      <div class="help-support" style="width: 33%">
        <p stlye="font-size: 17px">HELP &amp; SUPPORT</p>
        <p>FAQ</p>
        <p>Return Policy</p>
        <p>Loyalty Cusomer</p>
        <p>Contact Us</p>
      </div>
      <div class="follow-us" style="width: 33%">
        <p stlye="font-size: 17px">FOLLOW US</p>
        <ul>
        <li><a href="https://www.facebook.com/login/">Facebook</a></li>
        <li><a href="https://www.instagram.com/accounts/login/">Instagram</a></li>
        <li><a href="https://www.twitter.com/">Twitter</a></li>
        <li><a href="https://www.youtube.com/">Youtube</a></li>
        <ul>
      </div>
    </div>
    <div style="width: 50%" class="right-footer">
      <div>
        <strong><p>S&K Electronics</p></strong>
        <form class="form-inline">Get deals:
          <input type="email" class="form-control" size="50" placeholder="Email Address">
          <button type="button" class="btn btn-danger">Sign Up</button>
        </form>
      </div> 
    </div>
</footer>