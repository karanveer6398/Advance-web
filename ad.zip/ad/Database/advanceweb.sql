-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 14, 2019 at 04:25 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advanceweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ad_email` varchar(100) NOT NULL,
  `ad_password` varchar(100) NOT NULL,
  `ad_name` varchar(100) NOT NULL,
  `ad_dob` date NOT NULL,
  `ad_street` varchar(100) NOT NULL,
  `ad_suburb` varchar(50) NOT NULL,
  `ad_state` varchar(20) NOT NULL,
  `ad_country` varchar(30) NOT NULL,
  `ad_postcode` int(10) NOT NULL,
  `ad_phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ad_email`, `ad_password`, `ad_name`, `ad_dob`, `ad_street`, `ad_suburb`, `ad_state`, `ad_country`, `ad_postcode`, `ad_phone`) VALUES
('s&k@snk.com', '68c6c49ff31bc508f250371fad1a61e9693d691c', 'Karan Susil', '2019-05-01', '120 Spencer St', 'Melbourne', 'VIC', 'Australia', 3000, 469890386);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `b_name` varchar(100) NOT NULL,
  `b_address` varchar(100) NOT NULL,
  `b_phone` int(20) NOT NULL,
  `b_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`b_name`, `b_address`, `b_phone`, `b_email`) VALUES
('Apple', 'Docklands', 123142123, 'support@apple.com'),
('Dell', 'Docklands', 123456, 'support@dell.com'),
('Samsung', 'Docklands', 124123123, 'support@samsung.com');

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE `cards` (
  `c_email` varchar(100) NOT NULL,
  `card_num` int(16) NOT NULL,
  `exp_month` int(11) NOT NULL,
  `exp_year` int(11) NOT NULL,
  `card_cvv` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`c_email`, `card_num`, `exp_month`, `exp_year`, `card_cvv`) VALUES
('123abc123abc@gmail.com', 11, 11, 11, 111),
('testcard@gmail.com', 2147483647, 12, 1234, 123),
('', 0, 0, 0, 0),
('Susil123@gmail.com', 2147483647, 12, 1234, 123),
('firsttest@gmail.com', 2147483647, 12, 1234, 123),
('mirza@snk.com', 2147483647, 1019, 2022, 333),
('kevin@gmail.com', 2147483647, 12, 2022, 324),
('susil@gmail.com', 2147483647, 12, 2020, 999),
('kevin@gmail.com', 2147483647, 12, 2020, 222);

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `c_email` varchar(100) NOT NULL,
  `p_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_email` varchar(100) NOT NULL,
  `c_password` varchar(100) NOT NULL,
  `c_name` varchar(100) NOT NULL,
  `c_dob` date NOT NULL,
  `c_street` varchar(100) NOT NULL,
  `c_suburb` varchar(50) NOT NULL,
  `c_state` varchar(20) NOT NULL,
  `c_country` varchar(30) NOT NULL,
  `c_postcode` int(4) NOT NULL,
  `c_phone` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_email`, `c_password`, `c_name`, `c_dob`, `c_street`, `c_suburb`, `c_state`, `c_country`, `c_postcode`, `c_phone`) VALUES
('kevin@gmail.com', '802d3be54d783f4bc3ebcfd38dc0a1b9ffa1ef3d', 'Karan', '1998-07-10', '29 harkaway avenue', 'hoppers crossing', '', 'australia', 3029, 469890386);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `o_id` int(5) NOT NULL,
  `c_email` varchar(100) NOT NULL,
  `p_id` int(5) NOT NULL,
  `o_date` date NOT NULL,
  `o_status` varchar(30) NOT NULL,
  `o_price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`o_id`, `c_email`, `p_id`, `o_date`, `o_status`, `o_price`) VALUES
(1, 'kevin@gmail.com', 2, '2019-06-14', 'pending', 2200),
(2, 'kevin@gmail.com', 0, '2019-06-14', 'pending', 0),
(3, 's&k@snk.com', 12, '2019-06-14', 'pending', 3900);

-- --------------------------------------------------------

--
-- Table structure for table `o_p`
--

CREATE TABLE `o_p` (
  `p_id` int(5) NOT NULL,
  `o_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `p_id` int(5) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_color` varchar(20) NOT NULL,
  `p_price` int(10) NOT NULL,
  `p_stock` varchar(20) NOT NULL,
  `b_name` varchar(100) NOT NULL,
  `p_image` varchar(1000) NOT NULL,
  `p_date_add` date NOT NULL,
  `p_category` varchar(20) DEFAULT NULL,
  `p_clicks` int(11) NOT NULL,
  `p_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`p_id`, `p_name`, `p_color`, `p_price`, `p_stock`, `b_name`, `p_image`, `p_date_add`, `p_category`, `p_clicks`, `p_status`) VALUES
(1, 'Macbook Pro 13\'', 'Blue', 2000, '10', 'Apple', 'macbook13.jpg', '2019-05-10', 'Laptops', 12, 1),
(2, 'Dell 3350', 'White', 2200, '10', 'Dell', 'dell3350.jpg', '2019-05-10', 'Laptops', 23, 0),
(3, 'Samsung x360', 'White', 1890, '10', 'Samsung', 'x360.jpg', '2019-05-10', 'Laptops', 2435, 0),
(4, 'I Mac 17\'', 'Blue', 4000, '10', 'Apple', 'imac17.jpg', '2019-05-10', 'Laptops', 12, 0),
(5, 'Iphone Xs', 'Gold', 1600, '10', 'Apple', 'xs.jpg', '2019-05-10', 'Mobile', 234, 0),
(6, 'Iphone XR', 'Black', 1250, '10', 'Apple', '1.jpg', '2019-05-10', 'Mobile', 567, 0),
(7, 'Iphone 8\r\n', 'Space Grey', 850, '10', 'Apple', 'i8.jpg', '2019-05-10', 'Mobile', 5645, 0),
(8, 'Apple Iwatch series 4', 'white', 650, '50', 'Apple', 'iwtch4.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(9, 'Samsung Gear', 'black', 350, '300', 'Samsung', 'smgw.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(10, 'Apple Iwatch Series 3', 'white', 450, '50', 'Apple', 'ser3.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(11, 'Apple Iwatch Series 2', 'white', 350, '50', 'Apple', 's2.jpg', '2019-05-10', 'Smart Watches', 0, 0),
(12, 'Dell Inspiron 17\'', 'Black', 3900, '15', 'Dell', 'dellinspiron17.jpg', '2019-06-10', 'Laptops', 0, 0),
(13, 'Dell Inspiron 13 7000 2-in-1', 'silver', 1950, '8', 'Dell', 'dell13.jpg', '2019-05-16', 'Laptops', 0, 0),
(14, 'Galaxy samsung s10', 'black', 1800, '6', 'Samsung', 's10t.jpg', '2019-05-16', 'Mobile', 0, 0),
(15, 'Galaxy Note 10', 'Blue', 2250, '5', 'Samsung', '10note.jpg', '2019-05-16', 'Mobile', 0, 0),
(16, 'SAMSUNG GALAXY A7 ', 'Blue', 500, '12', 'Samsung', 'a7.jpg', '2019-05-16', 'Mobile', 0, 0),
(17, 'Fitbit Ionic Smart Fitness Watch', 'Slate Blue/Burnt Ora', 248, '5', 'Samsung', 'ftbt.jpg', '2019-05-16', 'Smart Watches', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ad_email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`b_name`);

--
-- Indexes for table `cards`
--
ALTER TABLE `cards`
  ADD KEY `c_email` (`c_email`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `c_email` (`c_email`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_email`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`o_id`),
  ADD UNIQUE KEY `o_id` (`o_id`),
  ADD KEY `c_email` (`c_email`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `o_p`
--
ALTER TABLE `o_p`
  ADD KEY `o_id` (`o_id`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `b_name` (`b_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `o_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
